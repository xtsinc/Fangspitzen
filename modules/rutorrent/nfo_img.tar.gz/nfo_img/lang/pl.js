theUILang.showNfoImg = "Show NFO...";
theUILang.nfoImgNotFound = "Can't find an NFO file in this directory";
theUILang.nfoImgNotFoundTitle = "Not found";
theUILang.nfoImgError = "An error ocurred: ";
theUILang.nfoImgErrorTitle = "Error";

